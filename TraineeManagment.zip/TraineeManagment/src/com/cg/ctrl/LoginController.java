package com.cg.ctrl;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.Login;
import com.cg.dto.Trainee;
import com.cg.service.TraineeService;

@Controller
public class LoginController {
	@Autowired
	private TraineeService traineeService=null;
/**********Service reference getter setters**********/
	public TraineeService getTraineeService() {
		return traineeService;
	}
	public void setTraineeService(TraineeService traineeService) {
		this.traineeService = traineeService;
	}
	/************controller methods*****************/
	@RequestMapping(value="showLoginPage",method=RequestMethod.GET)
	public String showLoginPage(Model model) {
		Login login = new Login();
		model.addAttribute("log",login);
		model.addAttribute("companyName","Capgemini");
		return "loginPage";
	}
	
	@RequestMapping(value="validateUser",method=RequestMethod.POST)
	public String loginTrainee(Model model,@ModelAttribute(value="log") Login login) {
		if(login.getUserName().equalsIgnoreCase("admin") && login.getPassword().equalsIgnoreCase("Admin"))
			return "MenuPage";
		model.addAttribute("message","UserName or password is incorrect.");
		return "loginPage";
	}
	@RequestMapping(value="addTraineePage",method=RequestMethod.GET)
	public String showAddTraineePage(Model model) {
		model.addAttribute("trainee",new Trainee());
		return "AddTrainee";
	}
	@RequestMapping(value="insertTrainee",method=RequestMethod.POST)
	public String insertAddTrainee(Model model,@ModelAttribute(value="trainee") @Valid Trainee trainee,BindingResult result) {
		traineeService.insertTrainee(trainee);
		model.addAttribute("addedTrainee",trainee);
		model.addAttribute("message","Trainee added successfully");
		return "SuccessPage";
	}
	
	public String getTraineeDetails(Trainee trainee) {
		Trainee responseTrainee = traineeService.findTrainee(trainee.getTraineeid());
		String html = "<f:form><label>Trainee Id : </label><label>"+responseTrainee.getTraineeid()+" </label><br><label>Trainee Name : </label><label>"+responseTrainee.getTraineename()+" </label><br><label>Trainee Location : </label><label>"+responseTrainee.getTraineeLocation()+" </label><br><label>Trainee Location : </label><label>"+responseTrainee.getTraineedomain()+" </label><br></f:form>";
		return html;
	}
	@RequestMapping(value="deleteTraineePage",method=RequestMethod.GET)
	public String showDeleteTraineePage(Model model) {
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		return "ConfirmDeletePage";
	}
	@RequestMapping(value="deleteTrainee",method=RequestMethod.POST)
	public String deleteTrainee(Model model,@ModelAttribute(value="trainee") @Valid Trainee trainee,BindingResult result) {
		Trainee responseTrainee = traineeService.deleteTrainee(trainee.getTraineeid());
		model.addAttribute("html","<f:form action=\"deleteTrainee.obj\" method=\"post\"><label>Trainee Id : </label><label>\"+responseTrainee.getTraineeid()+\" </label><br><label>Trainee Name : </label><label>\"+responseTrainee.getTraineename()+\" </label><br><label>Trainee Location : </label><label>\"+responseTrainee.getTraineeLocation()+\" </label><br><label>Trainee Location : </label><label>\"+responseTrainee.getTraineedomain()+\" </label><br><input type=\"submit\" value=\"Delete\"</f:form>");
		return "ConfirmDeletePage";
	}

	@RequestMapping(value="updateTraineePage",method=RequestMethod.GET)
	public String showUpdateTraineePage(Model model) {
		Trainee trainee = new Trainee();
		model.addAttribute("trainee",trainee);
		return "UpdatePage";
	}
	
	@RequestMapping(value="updateTrainee",method=RequestMethod.POST)
	public String updateTrainee(Model model,@ModelAttribute(value="trainee") @Valid Trainee trainee,BindingResult result) {
		Trainee responseTrainee = traineeService.updateTrainee(trainee);
		model.addAttribute("html","<table><tr><td>Trainee Id</td><td>Trainee Name</td><td>Trainee Location</td><td>Trainee Domain</td></tr><tr><td>"+responseTrainee.getTraineeid()+"</td><td>"+responseTrainee.getTraineename()+"</td><td>"+responseTrainee.getTraineeLocation()+"</td><td>"+responseTrainee.getTraineedomain()+"</td></tr></table>");
		return "UpdatePage";
	}
}
