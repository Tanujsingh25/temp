package com.cg.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.TraineeDao;
import com.cg.dto.Trainee;

@Service
public class TraineeServiceImpl implements TraineeService{
	@Autowired
	private TraineeDao traineeDao=null;
	public TraineeDao getTraineeDao() {
		return traineeDao;
	}
	public void setTraineeDao(TraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee insertTrainee(Trainee trainee) {
		return traineeDao.insertTrainee(trainee);
	}
	@Override
	public Trainee deleteTrainee(int traineeId) {
		return traineeDao.deleteTrainee(traineeId);
	}
	@Override
	public Trainee updateTrainee(Trainee trainee) {
		return traineeDao.updateTrainee(trainee);
	}
	@Override
	public Trainee findTrainee(int traineeId) {
		return traineeDao.findTrainee(traineeId);
	}
}
