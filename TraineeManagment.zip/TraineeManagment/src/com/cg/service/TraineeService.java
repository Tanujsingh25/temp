package com.cg.service;

import com.cg.dto.Trainee;

public interface TraineeService {
	public Trainee insertTrainee(Trainee trainee);
	public Trainee deleteTrainee(int traineeId);
	public Trainee updateTrainee(Trainee trainee);
	public Trainee findTrainee(int traineeId);
	
}
