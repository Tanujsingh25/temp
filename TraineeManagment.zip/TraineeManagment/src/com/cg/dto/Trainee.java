package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Trainee {
	@Id
	private int traineeid;
	private String traineename;
	private String traineedomain;
	private String traineeLocation;
	public Trainee() {
		super();
	}
	public Trainee(int traineeid, String traineename, String traineedomain, String traineeLocation) {
		super();
		this.traineeid = traineeid;
		this.traineename = traineename;
		this.traineedomain = traineedomain;
		this.traineeLocation = traineeLocation;
	}
	public int getTraineeid() {
		return traineeid;
	}
	public void setTraineeid(int traineeid) {
		this.traineeid = traineeid;
	}
	public String getTraineename() {
		return traineename;
	}
	public void setTraineename(String traineename) {
		this.traineename = traineename;
	}
	public String getTraineedomain() {
		return traineedomain;
	}
	public void setTraineedomain(String traineedomain) {
		this.traineedomain = traineedomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "Trainee [traineeid=" + traineeid + ", traineename=" + traineename + ", traineedomain=" + traineedomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
}
