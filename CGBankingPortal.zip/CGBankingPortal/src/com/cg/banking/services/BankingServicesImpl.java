package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import java.util.Date;
import java.io.*;
import java.net.MalformedURLException;
import java.util.*;
import java.sql.*; 
public class BankingServicesImpl implements BankingServices {
	AccountDAO accountDAO = new AccountDAOImpl(); 
	TransactionDAO transactionDAO = new TransactionDAOImpl();
	@Override
	public Account openAccount(String accountType, float initialBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(!(accountType.equalsIgnoreCase("Salary") || accountType.equalsIgnoreCase("Current") || accountType.equalsIgnoreCase("Saving"))) throw new InvalidAccountTypeException("Error : Account type is invalid.");
		if(initialBalance < 500) throw new InvalidAmountException("Error: "+initialBalance+" is not a valid initializing amount.\n Amount should be greater than Rs.499");
		int pinNumber = Integer.parseInt(String.format("%04d", new Random().nextInt(8999)+1000));
		Account account = new Account(pinNumber, accountType, "Active", initialBalance);
		accountDAO.save(account);
		Transaction transaction = new Transaction(initialBalance, "NEW" ,account);
		transactionDAO.save(transaction);
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(amount<1) throw new InvalidAmountException("Error: Amount is invalid.");
		Account account = accountDAO.findOne(accountNo);
		if(account == null) throw new AccountNotFoundException("Error : Account does not exist.");
		if(!account.getStatus().equalsIgnoreCase("Active")) throw new AccountBlockedException("Error : Your account is blocked.");
		float accountBalance = account.getAccountBalance()+amount; 
		account.setAccountBalance(accountBalance);;
		accountDAO.update(account);
		Transaction transaction = new Transaction(amount, "CREDIT",account);
		transactionDAO.save(transaction);
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(amount<1) throw new InvalidAmountException("Error: Amount is invalid.");
		Account account = accountDAO.findOne(accountNo);
		if(account == null) throw new AccountNotFoundException("Error : Account does not exist.");
		if(!account.getStatus().equalsIgnoreCase("Active")) throw new AccountBlockedException("Error : Your account is blocked.");
		if(amount>account.getAccountBalance()) throw new InsufficientAmountException("Error: Sorry this amount is not available.");
		account.setAccountBalance(account.getAccountBalance()-amount);
		accountDAO.update(account);
		Transaction transaction = new Transaction(amount, "DEBIT" , account);
		transactionDAO.save(transaction);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(transferAmount<1) throw new InvalidAmountException("Error: Amount is invalid.");
		Account accountFrom = accountDAO.findOne(accountNoFrom);
		Account accountTo = accountDAO.findOne(accountNoTo);
		if(accountFrom==null) throw new AccountNotFoundException("Error: Senders account does not exist.");
		if(accountTo==null) throw new AccountNotFoundException("Error: Receivers account does not exist.");
		if(pinNumber!=accountFrom.getPinNumber()) throw new InvalidPinNumberException("Error: PIN is incorrect please enter correct one.");
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
		accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		accountDAO.update(accountFrom);
		accountDAO.update(accountTo);
		Transaction transactionFrom = new Transaction(transferAmount, "DEBIT" , accountFrom);
		Transaction transactionTo = new Transaction(transferAmount, "CREDIT" , accountTo);
		transactionDAO.save(transactionFrom);
		transactionDAO.save(transactionTo);
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account = accountDAO.findOne(accountNo);
		if(account==null) throw new AccountNotFoundException("Error: Account does not exist check A/C no.");
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> accList = new ArrayList<>(); 
		accList = accountDAO.findAll();
		if(accList == null) throw new BankingServicesDownException("Error: Bak servers are down please try again later.");
		return accList;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,  MalformedURLException, IOException {
		Account account = accountDAO.findOne(accountNo);
		List<Transaction> txnList = new ArrayList<>();
		txnList = transactionDAO.findAll(accountNo);
		return txnList;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account = accountDAO.findOne(accountNo);
		if(account==null) throw new AccountNotFoundException("Error: Account does not exist check A/C no.");
		return account.getStatus();
	}
}
